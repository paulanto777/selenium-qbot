try {
  importScripts('/quillbot-sw.js' /*, and so on */);
} catch (e) {
  console.error(e);
}
